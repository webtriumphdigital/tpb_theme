<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


ob_start();
if ( !empty($options) ) {
    $i = 1;
    foreach ($options as $option) {
        if ( $option['value'] ) {
            ?>
            <option value="<?php echo esc_attr($option['value']); ?>" <?php selected($selected, $option['value']); ?>>
                <?php echo esc_attr($option['text']); ?>
            </option>
            <?php
            $i++;
        }
    }
}
$output = ob_get_clean();

if ( !empty($output) ) {
    $placeholder = !empty($field['placeholder']) ? $field['placeholder'] : sprintf(esc_html__('Filter by %s', 'justhome'), $field['name']);
?>
    <div class="form-group form-group-<?php echo esc_attr($key); ?>">
        <?php if ( (!isset($field['show_title']) || $field['show_title']) && !empty($field['name']) ) { ?>
            <label class="heading-label">
                <?php echo trim($field['name']); ?>
            </label>
        <?php } ?>
        <div class="form-group-inner inner select-wrapper">
            <?php if ( !empty($field['icon_html']) ) { ?>
                <?php echo trim( $field['icon_html'] ); ?>
            <?php } ?>
            <select name="<?php echo esc_attr($name); ?>" class="form-control" id="<?php echo esc_attr( $args['widget_id'] ); ?>_<?php echo esc_attr($key); ?>" data-placeholder="<?php echo esc_attr($placeholder); ?>">
                <option value=""><?php echo esc_html($placeholder); ?></option>
                <?php echo trim($output); ?>
            </select>
        </div>
    </div><!-- /.form-group -->
<?php }